"""Example: a Python plugin that returns a table.

A plugin is any .py file in this folder with:
    TITLE = "Panel name"
    def run(tickers: list[str]) -> DataFrame | dict | str | plotly Figure | list of those
Paste your existing code inside run() and return what you want displayed.
"""
import pandas as pd

import data

TITLE = "Biggest pre-market movers (example)"


def run(tickers):
    snap = data.premarket_snapshot(tickers)
    snap = snap.dropna(subset=["Gap %"])
    return snap.reindex(snap["Gap %"].abs().sort_values(ascending=False).index).head(5)[
        ["Ticker", "Gap %", "PM volume"]]
