"""Example: show the output of a script you already run in your terminal.

Copy this file, change COMMAND to whatever you normally type, and it shows up
as its own panel in the "My Scripts" tab. Use {tickers} to pass the watchlist.
"""
import subprocess

TITLE = "My terminal script (example)"
# e.g. "python ~/scripts/premarket_scan.py {tickers}"
COMMAND = "echo Watchlist: {tickers} && date"


def run(tickers):
    cmd = COMMAND.format(tickers=" ".join(tickers))
    res = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=120)
    return res.stdout + (("\n[stderr]\n" + res.stderr) if res.stderr else "")
