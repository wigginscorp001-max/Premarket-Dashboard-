#!/usr/bin/env bash
# One-command launcher: sets itself up the first time, then opens the dashboard.
cd "$(dirname "$0")"
PY=$(command -v python3.13 || command -v python3.12 || command -v python3.11 || command -v python3.10 || command -v python3)
if ! "$PY" -c 'import sys; sys.exit(sys.version_info < (3, 10))' 2>/dev/null; then
  echo "Python 3.10 or newer is needed. Install it from https://www.python.org/downloads/ then run ./run.sh again."
  exit 1
fi
if [ ! -d .venv ]; then
  echo "First-time setup: installing (takes 1-3 minutes)..."
  "$PY" -m venv .venv && .venv/bin/pip install -q --upgrade pip && .venv/bin/pip install -q -r requirements.txt || { rm -rf .venv; exit 1; }
fi
exec .venv/bin/streamlit run app.py "$@"
